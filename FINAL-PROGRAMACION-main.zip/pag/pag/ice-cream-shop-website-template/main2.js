


function validateForm() {  //esta función valida el formulario y sus datos dentro

    // variables para almacenar el valor de diferentes campos de un formulario, obtienen el valor de campos específicos en el documento HTML utilizando document.getElementById.

    let email = document.getElementById('inputEmail').value; 
    let name = document.getElementById('inputName').value;
    let apellido = document.getElementById('inputApellido').value;
    let phone = document.getElementById('inputPhone').value;
    let domicilio = document.getElementById('inputDomicilio').value;
    let pago = document.getElementById('inputGenero').value;
    let tarjeta = document.getElementById('inputDni').value;
    let clave = document.getElementById('inputClave').value;
    let opcion = document.getElementById('inputOpcion').value;


    if (email == "" || name == "" || apellido == "" || phone == "" || domicilio == "" || pago == "" || tarjeta == "" || clave == "" || opcion == "") {
        alert('Debe rellenar todos los campos');
        return false;
    }

    alert('Compra exitosa.');
    return true;


}



// Función para mostrar los datos
function showData() {

    let listPeople; //variable utilizada para almacenar los datos recuperados del localStorage

    if (localStorage.getItem('listPeople') == null) { //el localStorage nos tiene que traer una lista == null
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem("listPeople"));// sino, nos trae un listPeople con el JSON.parse en el localStore
    }

    var html = ""; //variable html es creada

    //// Agrega celdas HTML con los valores de las propiedades de 'element'
    
    listPeople.forEach(function(element, index) { //para cada forEach, nos trae una función, que trae un elemento y un index
        html += "<tr>";
        html += "<td>" + element.email + "</td>";
        html += "<td>" + element.name + "</td>";
        html += "<td>" + element.apellido + "</td>";
        html += "<td>" + element.phone + "</td>";
        html += "<td>" + element.domicilio + "</td>";
        html += "<td>" + element.pago + "</td>";
        html += "<td>" + element.tarjeta + "</td>";
        html += "<td>" + element.clave + "</td>";
        html += "<td>" + element.opcion + "</td>";
    
        //cambio de color en los botones "enviar" y "editar"
        html += '<td><button onclick="deleteData(' + index + ')" class="btn" style="background-color: #f81919ad; color: #FFF;">Eliminar dato</button> <button onclick="updateData(' + index + ')" class="btn" style="background-color: #299e4cad; color: #FFF;">Editar dato</button></td>';
        html += "</tr>";
    });
    

    document.querySelector('#tableData tbody').innerHTML = html;
}

function isDniUnique(dni, listPeople) {
    return listPeople.every(function(person) {
      return person.dni !== dni;
    });
}

// Función para agregar datos
function AddData() {
    if (validateForm() == true) {
        let email = document.getElementById('inputEmail').value;
        let name = document.getElementById('inputName').value;
        let apellido = document.getElementById('inputApellido').value;
        let phone = document.getElementById('inputPhone').value;
        let domicilio = document.getElementById('inputDomicilio').value;
        let pago = document.getElementById('inputGenero').value;
        let tarjeta = document.getElementById('inputDni').value;
        let clave = document.getElementById('inputClave').value;
        let opcion = document.getElementById('inputOpcion').value;

        var listPeople;

        if (localStorage.getItem('listPeople') == null) {
            listPeople = [];
        } else {
            listPeople = JSON.parse(localStorage.getItem("listPeople"));
        }

        if (!isDniUnique (dni, listPeople)) {
            Swal.fire({
                title: 'Error!',
                text: 'DNI ya en uso',
                icon: 'error',
                confirmButtonText: 'Volver'
            });
            return;
        }

        listPeople.push({
            email: email,
            name: name,
            apellido: apellido,
            phone: phone,
            domicilio: domicilio,
            pago: pago,
            tarjeta: tarjeta,
            clave: clave,
            opcion: opcion,
        });

        localStorage.setItem('listPeople', JSON.stringify(listPeople));
        showData();

        document.getElementById('inputEmail').value = "";
        document.getElementById('inputName').value = "";
        document.getElementById('inputApellido').value = "";
        document.getElementById('inputPhone').value = "";
        document.getElementById('inputDomicilio').value = "";
        document.getElementById('inputGenero').value = "";
        document.getElementById('inputDni').value = "";
        document.getElementById('InputClave').value = "";
        document.getElementById('inputOpcion').value = "";

       
        window.location.href = '/ice-cream-shop-website-template/html/index.html';

        // Muestra la alerta después de la redirección
        Swal.fire({
            title: 'Compra realizada',
            text: 'Te enviaremos un Email con los datos de tu compra',
            icon: 'success',
            confirmButtonText: 'Volver'
        });
    }
}



function AddData2() {
    if (validateForm() == true) {
        let email = document.getElementById('inputEmail').value;
        let name = document.getElementById('inputName').value;
        let apellido = document.getElementById('inputApellido').value;
        let phone = document.getElementById('inputPhone').value;
        let domicilio = document.getElementById('inputDomicilio').value;
        let pago = document.getElementById('inputGenero').value;
        let tarjeta = document.getElementById('inputDni').value;
        let clave = document.getElementById('inputClave').value;

        let opcion = document.getElementById('inputOpcion').value;

        var listPeople;

        if (localStorage.getItem('listPeople') == null) {
            listPeople = [];
        } else {
            listPeople = JSON.parse(localStorage.getItem("listPeople"));
        }

        if (!isDniUnique (dni, listPeople)) {
            Swal.fire({
                title: 'Error!',
                text: 'DNI ya en uso',
                icon: 'error',
                confirmButtonText: 'Volver'
            });
            return;
        }

        listPeople.push({
            email: email,
            name: name,
            apellido: apellido,
            phone: phone,
            domicilio: domicilio,
            pago: pago,
            tarjeta: tarjeta,
            clave: clave,
            opcion: opcion,
        });

        localStorage.setItem('listPeople', JSON.stringify(listPeople));
        showData();

        document.getElementById('inputEmail').value = "";
        document.getElementById('inputName').value = "";
        document.getElementById('inputApellido').value = "";
        document.getElementById('inputPhone').value = "";
        document.getElementById('inputDomicilio').value = "";
        document.getElementById('inputGenero').value = "";
        document.getElementById('inputDni').value = "";
        document.getElementById('inputClave').value = "";
        document.getElementById('inputOpcion').value = "";

       
        Swal.fire({
            title: 'Compra realizada',
            text: 'Te enviaremos un Email con los datos de tu compra',
            icon: 'success',
            confirmButtonText: 'Volver'
        });
    }
}


// Función para eliminar datos
function deleteData(index) {
    var listPeople; //Se declara una variable listPeople para almacenar la lista de personas.
    if (localStorage.getItem('listPeople') == null) { //Esta línea comprueba si hay datos almacenados en el almacenamiento local del navegador bajo el nombre 'listPeople'. Si no hay datos almacenados, inicializa listPeople como una matriz vacía.
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem("listPeople"));
    }

    listPeople.splice(index, 1); //elimina un elemento de la matriz
    localStorage.setItem('listPeople', JSON.stringify(listPeople));
    showData();
}

// Función para actualizar datos

function updateData(index) { //actualiza datos de una persona en función del índice proporcionado.
    document.getElementById("btnAdd").style.display = 'none';
    document.getElementById("btnUpdate").style.display = 'block'; //oculta el boton al inicio

    var listPeople;
    if (localStorage.getItem('listPeople') == null) {
        listPeople = [];
    } else {
        listPeople = JSON.parse(localStorage.getItem("listPeople"));
    }
    
    //Cada línea toma el elemento del formulario (por ejemplo, 'inputEmail') y le asigna el valor correspondiente del objeto listPeople en la posición index

    document.getElementById('inputEmail').value = listPeople[index].email;  
    document.getElementById('inputName').value = listPeople[index].name;
    document.getElementById('inputApellido').value = listPeople[index].apellido;
    document.getElementById('inputPhone').value = listPeople[index].phone;
    document.getElementById('inputDomicilio').value = listPeople[index].domicilio;
    document.getElementById('inputGenero').value = listPeople[index].pago;
    document.getElementById('inputDni').value = listPeople[index].tarjeta;
    document.getElementById('inputClave').value = listPeople[index].clave;
    document.getElementById('inputOpcion').value = listPeople[index].opcion;

    document.querySelector("#btnUpdate").onclick = function () {
        if (validateForm() == true) {
            listPeople[index].email = document.getElementById('inputEmail').value;
            listPeople[index].name = document.getElementById('inputName').value;
            listPeople[index].apellido = document.getElementById('inputApellido').value;
            listPeople[index].phone = document.getElementById('inputPhone').value;
            listPeople[index].domicilio = document.getElementById('inputDomicilio').value;
            listPeople[index].pago = document.getElementById('inputGenero').value;
            listPeople[index].tarjeta = document.getElementById('inputDni').value;
            listPeople[index].clave = document.getElementById('inputClave').value;
            listPeople[index].opcion = document.getElementById('inputOpcion').value;

            localStorage.setItem('listPeople', JSON.stringify(listPeople));
            showData();

            //Cada línea toma el elemento del formulario (por ejemplo, 'inputEmail') y le asigna el valor correspondiente del objeto listPeople en la posición index

            document.getElementById('inputEmail').value = "";  
            document.getElementById('inputName').value = "";
            document.getElementById('inputApellido').value = "";
            document.getElementById('inputPhone').value = "";
            document.getElementById('inputDomicilio').value = "";
            document.getElementById('inputGenero').value = "";
            document.getElementById('inputDni').value = "";
            document.getElementById('inputClave').value = "";
            document.getElementById('inputOpcion').value = "";

            document.getElementById("btnAdd").style.display = 'block';
            document.getElementById("btnUpdate").style.display = 'none';
        }
    };
}

// Cuando el documento HTML se ha cargado por completo, se llama a la función showData para cargar y mostrar los datos almacenados en la tabla al cargar la página.
document.addEventListener("DOMContentLoaded", showData);
